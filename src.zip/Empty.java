public class Empty {

    @Override
    public String toString(){
        return " ";
    }
}
